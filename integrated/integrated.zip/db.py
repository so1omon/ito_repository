import os


def check_location(os_name): # 운영체제에 맞는 client location 가져오기 (윈도우, 리눅스)

    if os_name=='Windows':

        return 'instantclient_21_3'

    elif os_name=='Linux':

        return 'instantclient_21_6'

# instantclient 환경변수 추가할 때 필요한 디렉토리명 리턴

# Windows에서는 v21_3, Linux(중계 DB server) 에서는 v21_4 사용 중

cx_info={ # eHR Oracle DB 접속 정보

    "id":"silver",

    "pw":"silver",

    "host":"192.168.20.13:1521/IDTCORA"

}

pymysql_info={ # 중계 DB (Maria) 접속 정보

    'host':'192.168.20.19',

    'user':'root',

    'password':'Azsxdc123$',

    'db':'connect',

    'charset':'utf8'

}

col_inout_table=['EMP_CODE','WORK_DATE','WORK_CD','WORK_INFO','WORK_INFO_DAY','WORK_INFO_CLOCK','HOME_WORK_YN']

col_origin_table=['EMP_ID','APPR_YMD','YMD','STA_HM','END_HM','TYPE','APPL_ID','DEL_YN','BF_APPL_ID','APPL_TXT','REWARD_TYPE', 'RSN']


col_merge_table=['YMD','EMP_ID', 'NAME','ORG_NM','SHIFT_CD','WORK_TYPE','PLAN1','INOUT', 'FIX1','ERROR_INFO','DAYOFF1_TIME',
 
                 'DAYOFF1_ID','DAYOFF2_TIME','DAYOFF2_ID','OVER1_TIME','OVER1_ID','BUSI_TRIP1_TIME','BUSI_TRIP1_ID',

                 'BUSI_TRIP2_TIME','BUSI_TRIP2_ID','HOME_ID','ETC_INFO','ETC_ID','REWARD_TIME','REWARD_ID','CAL_OVERTIME',

                 'CAL_MEAL','RSN']

col_insert_table=['EMP_ID','SHIFT_CD','WORK_TYPE']

if __name__=='__main__': # login_info.py 실행 시
    print(len(col_merge_table))
